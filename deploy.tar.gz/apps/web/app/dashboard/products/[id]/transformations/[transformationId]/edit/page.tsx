
import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import EditTransformationForm from '@/app/ui/transformations/edit-form';

export default async function Page({ params }: { params: { id: string, transformationId: string } }) {
    const { id, transformationId } = await params;

    const [product, transformation, ingredients] = await Promise.all([
        prisma.masterProduct.findUnique({
            where: { id },
            include: { supplierProducts: true }
        }),
        prisma.transformation.findUnique({
            where: { id: transformationId },
            include: {
                outputs: {
                    include: { ingredient: true }
                }
            }
        }),
        prisma.ingredient.findMany({
            orderBy: { name: 'asc' },
            include: {
                transformationOutputs: {
                    include: {
                        transformation: {
                            include: {
                                sourceProduct: true
                            }
                        }
                    }
                }
            }
        })
    ]);

    if (!product || !transformation) {
        notFound();
    }

    return (
        <main>
            <h1 className="mb-4 text-2xl font-bold">Editar Transformación: {product.name}</h1>
            <EditTransformationForm
                product={product}
                transformation={transformation}
                ingredients={ingredients}
            />
        </main>
    );
}
