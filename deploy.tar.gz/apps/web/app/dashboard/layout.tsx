import SideNav from '@/app/ui/dashboard/sidenav';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export default async function Layout({ children }: { children: React.ReactNode }) {
    const session = await auth();
    const appConfig = await prisma.appConfig.findUnique({
        where: { id: 'default' },
    });

    return (
        <div className="flex h-screen flex-col md:flex-row md:overflow-hidden">
            <div className="w-full flex-none md:w-64">
                <SideNav user={session?.user} logoUrl={appConfig?.logoUrl} />
            </div>
            <div className="flex-grow p-6 md:overflow-y-auto md:p-12">{children}</div>
        </div>
    );
}
