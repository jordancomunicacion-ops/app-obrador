import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
    const email = 'gerencia@sotodelprior.com'
    const password = '123456'
    const name = 'Gerencia'

    console.log(`Creating user: ${email}...`)

    const hashedPassword = await bcrypt.hash(password, 10)

    const user = await prisma.user.upsert({
        where: { email },
        update: {
            password: hashedPassword,
            role: 'ADMIN' // Ensure admin access
        },
        create: {
            email,
            name,
            password: hashedPassword,
            role: 'ADMIN',
        },
    })
    console.log('User created:', user)
}

main()
    .catch((e) => {
        console.error(e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    })
